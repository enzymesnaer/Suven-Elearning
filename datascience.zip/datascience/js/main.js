function setBindings(){$("#g_in_touch").click(function(){return $("html, body").animate({scrollTop:$("#footer").offset().top+-60},800),!1})}function table(){$(".first-row-heading").html("<tr><th><h1>Batch</h1></th><th><h1>Day</h1></th><th><h1>Start-Date</h1></th><th><h1>End-Date</h1></th><th><h1>Timing</h1></th><th><h1>Fees*</h1></th></tr>"),$(".first-row-heading2").html("<tr><th><h1>Batch</h1></th><th><h1>Day</h1></th><th><h1>Timing</h1></th><th><h1>Start-Date</h1></th><th><h1>End-Date</h1></th><th><h1>Fees*</h1></th><th><h1>Interview  dates</h1></th></tr>"),$(".first-row-heading3").html("<tr><th><h1>Course</h1></th><th><h1>Batch Code</h1></th><th><h1>Location</h1></th><th><h1>Dates</h1></th><th><h1>Timings</h1></th><th><h1>Fees*</h1></th></tr>")}function address(){$(".dadar_address").html("<strong><span class='glyphicon glyphicon-map-marker' style='font-size: 20px; color:#ff4d4d'></span>kalpana classes</strong><br> 205, 2nd Floor, Pearl Centre,<br>Senapati Bapat Road, Dadar West, <br>Mumbai 400028.<br><span class='glyphicon glyphicon-phone-alt' style='font-size: 20px; color:#ffc34d'></span> 022-24321775 <br> <span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span> 9867674602.");$(".thane_address").html("<strong><span class='glyphicon glyphicon-map-marker' style='font-size: 20px; color:#ff4d4d'></span>SCTPL-THANE </strong><br>c/o : Kalpana Coaching Classes<br>202, Second Floor, Crystal Court, <br>Above lagoo Bandhu Jewellers, <br>B-Cabin, Thane-West, Mumbai 400601.<br><span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span> 9870014450.<br><span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span> 9967504602.");$(".borivali_address").html("<strong><span class='glyphicon glyphicon-map-marker' style='font-size: 20px; color:#ff4d4d'></span>Suven Consultants & Technology Pvt. Ltd.</strong><br>c/o : Kalpana Coaching Classes,<br>Borivali (West).<br><h6><em>5 min walk from Station</em></h6><span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#ffc34d'></span> 8097435788<br> <span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span>9867674602.");$(".chembur_address").html("<strong><span class='glyphicon glyphicon-map-marker' style='font-size: 20px; color:#ff4d4d'></span>Suven Consultants & Technology Pvt. Ltd.</strong><br>4/B wing,Trishul Apartments,<br>Sindhi Society Rd Number 1,<br>Chembur, Mumbai 400071.<br><span class='glyphicon glyphicon-phone-alt' style='font-size: 20px; color:#ffc34d'></span> 022-25277413 <br> <span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span>9870014450.");$(".dadarnew_address").html("<strong><span class='glyphicon glyphicon-map-marker' style='font-size: 20px; color:#ff4d4d'></span>Suven Consultants & Technology Pvt. Ltd. <br>c/o </strong>kalpana classes<br> 205, 2nd Floor, Pearl Centre,<br>Senapati Bapat Road, Dadar West, <br>Mumbai 400028.<br><span class='glyphicon glyphicon-phone-alt' style='font-size: 20px; color:#DDA6AE'></span> 022-24362136.<br><span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span>9867674602.");$(".thanenew_address").html("<strong><span class='glyphicon glyphicon-map-marker' style='font-size: 20px; color:#ff4d4d'></span>Suven Consultants & Technology Pvt. Ltd. <br>c/o </strong>kalpana classes<br>202, Second Floor, Crystal Court, <br>Above lagoo Bandhu Jewellers, <br>B-Cabin, Thane-West, Mumbai 400601.<br><span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span> 9967504602.<br><span class='glyphicon glyphicon-phone' style='font-size: 20px; color:#DDA6AE'></span>  9870014450.")}function maps(){$(".dadar_map").html('<iframe src="https://www.google.com/maps/embed/v1/place?q=kalpana+classes+mumbai&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>');$(".thane_map").html('<iframe src="https://www.google.com/maps/embed/v1/place?q=kalpana+classes+thane&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>');var o='<iframe src="https://www.google.com/maps/embed/v1/place?q=kandivali+ghanysham+enclave&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>';$(".kandivali_map").html(o),$(".kandivali_map").html(o);$(".chembur_map").html('<iframe src="https://www.google.com/maps/embed/v1/place?q=Suven+Consultants,+Sindhi+Society+Road,+Chembur+East,+Mumbai,+Maharashtra,+India&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>')}function comboOffer(){$(".comboOffer").html('<table class="table table-bordered"><tr><th>* Fees breakup Oracle SQl = Rs. 4400/-  and oracle PL/SQL = 6400/- if taken both total 9400 /- </th></tr><tr><th> Combo offer 1: Take <a href="http://monster.suvenconsultants.com/" target="_blank" >Web Technologist Level 1 </a> + Oracle SQL  = 8000 + 4400  = <del>12400</del> 11400 /-</th></tr><tr><th> Combo offer 2: <a href="http://ocpjp.suvenconsultants.com/" target="_blank">OCJA + OCJP </a> + Oracle SQL  = <del>13900</del> = 12400/- </th></tr></table>');$(".comboOffer2").html('<table class="table table-bordered"><tr><th>* Fees : 2950/- ( Inclusive of Printed Notes , Online software and Certification test )</th></tr><tr><th> * Fees : 2950/- for admission taken before the start date, else 3450/- on start date </th></tr></table>')}





function python_rar() {
    
var password=prompt("Please enter your Password");    
    
var enc_url="U2FsdGVkX19HJimeUAFa/Qa2cv1SI0Rygv0IBaAJedKjNXhsT1UJTtBQVFtYMGHeyOcCXTk6fsUhzPCu9dKTog==";


var url = CryptoJS.AES.decrypt(enc_url, password).toString(CryptoJS.enc.Utf8);

    ((url !== undefined) && (url !== null) && (url.trim() !== "")) ?  window.open(url, "_blank") :  alert("Password you enter was incorrect")
    
}

function python_da() {
    
var password=prompt("Please enter your Password");    
    
var enc_url="U2FsdGVkX1+GvM6RKC5qya4VlQ904oY/+pPD5DNYD/ZIrT8pzjnwkH4733FJszkvRu4DVDjgXmDqNfEpcla1Fzhzq97wMp8I2l6SWve9FRM=";

var url = CryptoJS.AES.decrypt(enc_url, password).toString(CryptoJS.enc.Utf8);

    ((url !== undefined) && (url !== null) && (url.trim() !== "")) ?  window.open(url, "_blank") :  alert("Password you enter was incorrect")
    
}

function python_rar2() {
    
var password=prompt("Please enter your Password");    
    
var enc_url="U2FsdGVkX1+4TSPq03K89iVMHICIPRpmP0N305MrPVGsCEHhLhhUXPfjLKdZYS+4BEG21cFULOcZachgQo3GI4jqOgWwpHTQCNPqGu9G4br7mTJWr7uJ12IXr2Eb5rag";

var url = CryptoJS.AES.decrypt(enc_url, password).toString(CryptoJS.enc.Utf8);

((url !== undefined) && (url !== null) && (url.trim() !== "")) ?  window.open(url, "_blank") :  alert("Password you enter was incorrect")

}




function aml(o) {

var password=prompt("Please enter your Password");    
    
var enc_url1 = ""; //--

var enc_url2 = "U2FsdGVkX1+Nf7oKIlxcJJH8hBKvIRs7/ZBLVpdFhfnkMkr6+/+koQI7/MWCIufNEj23B0dXRKONYOdOnIkQOLepxr6YWjuyr5EsPRLOMTo=";

var enc_url3 = "U2FsdGVkX18VZob77+usR3AViieUlKnwbVLw9n6PRoN9621Ln7AyvuzCKzTQMTk7ujL/o8w1490mPUjjqLPGoT7UciOYo5Lx+PuR0NUbbDc=";

var enc_url4 = "U2FsdGVkX185d+dHUggoBNoGKW5xR7oCLesBRFo8TwsDSWngcGs9vVUbJV/je8R71Wq1OORn4bfbX+wi1UdrHA==";

var enc_url5 = "U2FsdGVkX19sCDoHxGDwJJzJp8P1xpbxGBMi6/y+/Hvk6X2Qaxs6KD2HMBQmrcVLJPzTEunCW6QFv5e7ys3pgjirVft1KLBXCCihoDDHVgA=";

var enc_url6 = "U2FsdGVkX1/x1taMuUWa9vHnqRldg4VxiB73PO8ujt1IM5T2iMDpWd5DBx+sb6CeBzzytuSHoOsHNkHwIKVf1w==";

var enc_url7 = "U2FsdGVkX1+VHquHE8lhXDLMSgOjiDyoP9p6+op6TugIV0QDKHXNZL3kpJaf+vlwb+unmVtmf82QiYzfcVZ6PnARXUAQP3ujv2QfV4DCgtY=";

var enc_url8 = "U2FsdGVkX19RiubuXMJ8+BwZpxJ64rWB2h3a0xrhs70sfs5xgy+22TE9jnXbkPaj4OCOu4PtuUgHFsH3XkuHYMEsKfUPUnLef7+8X/TwaQI=";

var enc_url9 = "U2FsdGVkX1/7WkwW7CkH+bFlrEiC5thZ/Zt2Jg0822zsVShvjrtk/4MtoOH1xbLqyZ0zGd7YJFa7aaGZI0H2Tt9GgrTOA3mdlFlvdzN0S1JnrOAX5rYxeVJihavbrGbA";

var enc_url10 = "U2FsdGVkX1/8Ar8Jje72bX1Wbs1BY4UDxep1M6XgAIAYYWxcqqcqZq7LLcI3AHxPJb0ll+ngsT1vzNfFPWGd9qjwLXHgdADwqTi4/Diba1JS1uyMappL/ADUJMutp/na";

var enc_url11 = "U2FsdGVkX1/cHWstD0hDGEbyeepAnONkfuwXtTY9cPVDLnQmfqleZqY/4ZVn/rMXg9oVaeANarSVBay/fKQG6cu/qTDPaJp5XWAzDmy7IcU=";

var enc_url12 = "U2FsdGVkX1+4c2EqvMc2DLUy+V9eSG3RxCCPvbKie76fCj773k674yJZyKDe/zgLaHiOzA51SGsXsdNK1p4T2vyGJ9FVLxU6SbSM/Xo1vCX0qySB1pUzjn7AersJxVsf";


var url = CryptoJS.AES.decrypt(eval("enc_url"+String(o)), password).toString(CryptoJS.enc.Utf8);

    
((url !=undefined) && (url != null) && (url.trim() !="")) ? 2 == o ? window.open(url, "_blank") : 3 == o ? window.open(url, "_blank") : 4 == o ? window.open(url, "_blank") : 5 == o ? window.open(url, "_blank") : 6 == o ? window.open(url, "_blank") : 7 == o ? window.open(url, "_blank") : 8 == o ? window.open(url, "_blank") : 9 == o ? window.open(url, "_blank") : 10 == o ? window.open(url, "_blank") : 11 == o ? window.open(url, "_blank") : 12 == o && window.open(url, "download") : alert("Password you enter was incorrect")
}



function hadoop_pdf(o) {

var password=prompt("Please enter your Password");    
    
var enc_url1 = "U2FsdGVkX18kht+TNsuEmVO9gy6dsx7ZX0dV1AyPKfegD2M9cNZFZt9gFY0cxwM7jflVRXz5T4CDL4fvU9Uldqr5iiv1hRl3IwObPP1lFybL3K1OOZWFegpLM5sR4075"; 

var enc_url2 = "U2FsdGVkX18xMF8kQ/SuZcqKC3Uc69ezuzyju6ftD85eVI8ePozE5rsdWAVmCa5sIHE4Jkpp2+YoChhN2kMEZYmGKLoUiJ+bXUOOv0rfjV8I3DGRXYZvEA2yH3uuPWCn";

var enc_url3 = "U2FsdGVkX1+oAoKJR4QLWQDqyWk9G3v5xgveH2g98pv2mhnPkzkeyvkR7H5V9q5UjbGagoCw7ZgQ3GhDazFEF8ajxHDx12bBrOxWc/dL/2LO8Yauk3w038xL80TFG0CR";

var enc_url4 = "U2FsdGVkX1/CtQH/aF5SN/yTVmAcUOeQG2jcFiVgYDrl+WKTypvIZ7FcLUTwSjUaBJAkNpkbgXOQyqsC9GxVGw==";

var enc_url5 = "U2FsdGVkX1+tOP8migCub+lhH8Pazdz1ZT1e813USVjG82pcYYKWgCHQNsTseRAlkO7d1P4LUmHkDZgJvTiUDzsVoX+wx2C/+j9w78I2/vo=";

var enc_url6 = "U2FsdGVkX1/hCBgVv03dY7ML4CMGqNSYJphv5krRAOuL+kF1Nhg815p8FrjOaZ9wR2mdttxCJTi+WLnQGSo6FEOTxzrfN7ne8bQBnJC5nUw=";

var enc_url7 = "U2FsdGVkX1+AkBRukU3Tajfm/fXv9la7K5jLEcBottLbLuPioztCDejm0KDi4Dgg3ppfRXhj7em8cfWLq4c6DdkHZ/1RfD126gKll521yVg=";

var enc_url8 = "U2FsdGVkX1+JxB8595Mq7KDnsC0wcHcrYny3i2ttwJ8HqQ6xsIKFLLS7uiGDG87AbRi9/hpYVxSNpefPMg22rQEaxOZGpov7wtwNoNF3fd8=";

var enc_url9 = "U2FsdGVkX1+SWxb7Cf537NyEAXJ6tDlP1ZtFWR/Q6TorqMQTJp6j+QyxrNVU8thzhE/fNxmTS+8Zt8gugfsjvGJSySp2wMswYXLWeAcJyT5wi109u9s1gMWKnsrPz8uu";

var enc_url10 = "U2FsdGVkX1+q9b3jiJe4PNbzjqEhnqQLZfC0+7YsJ/1rZ0NUCdXQC5FCz1a5HQPAk/0XtWOnrIQvfK6DGI/oKHNFIvstN5YvEo72kX62W+ZqGagXKvwzLJq+21lNW8B+";

var enc_url11 = "U2FsdGVkX19lAc8E824Tdxtx8atoMm3HMzAxpqEJd3KY6lF59zLQgbYvWjavCntmbDLZb8JFfJ0SSRiUNr+ci+dPaUc4DN0EQUQ47Mv8bSo=";

var enc_url12 = "U2FsdGVkX1/vqP43U3ofm3nUYJiv0q2noiMIwpbbdn7pM10ff5/ZMP//ojaPvkV65Gr1eSdK56o4eKY72PHTDGBbGgaQQh6OeZKmymBEi75A/gZUqdcJHgwrj5myt1cl";


var url = CryptoJS.AES.decrypt(eval("enc_url"+String(o)), password).toString(CryptoJS.enc.Utf8);

    
((url !=undefined) && (url != null) && (url.trim() !="")) ? 1 == o ? window.open(url, "_blank") : 2 == o ? window.open(url, "_blank") : 3 == o ? window.open(url, "_blank") : 4 == o ? window.open(url, "_blank") : 5 == o ? window.open(url, "_blank") : 6 == o ? window.open(url, "_blank") : 7 == o ? window.open(url, "_blank") : 8 == o ? window.open(url, "_blank") : 9 == o ? window.open(url, "_blank") : 10 == o ? window.open(url, "_blank") : 11 == o ? window.open(url, "_blank") : 12 == o && window.open(url, "download") : alert("Password you enter was incorrect")

}


$(document).ready(function() {
    setBindings(), table(), comboOffer(), address(), maps()
}), $(".navbar-collapse a").click(function() {
    $(".navbar-collapse").collapse("hide")
});